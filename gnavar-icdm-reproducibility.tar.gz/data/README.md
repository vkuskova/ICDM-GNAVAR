# Data

All three real-data datasets are included directly in this folder, so every experiment runs
without any external download. The synthetic experiments generate their own data from the
code and need no files.

## Included here

### rv_dataset.csv  (realized volatility, Section VII)
Daily realized volatility for eight international equity indices (.SPX, .GDAXI, .FCHI,
.FTSE, .OMXSPI, .N225, .KS11, .HSI), 2,615 trading days. Source: Son et al.,
"Forecasting global stock market volatility...", J. Forecast. 42(7):1539-1559, 2023.
Loaded by `notebooks/experiment_rv.ipynb`.

### wdi_reversal_panel.csv  (WDI development indicators, Section VII)
World Development Indicators country-year panel, 1970-2023, columns include ISO3, year,
gdp_growth, resource_rents, investment, trade_openness, fdi. Source: World Bank, World
Development Indicators, 2024. Loaded by `notebooks/experiment_wdi_resource_curse.ipynb`.

### beijing_panel.npz  (Beijing air quality, Section VII)
Preprocessed Beijing Multi-Site Air-Quality arrays: per-station `X__<station>` (hourly
pollutant + meteorology series, 35064 x 11) and `runs__<station>` (contiguous-run indices),
for 12 stations including the four used in the paper (Nongzhanguan, Tiantan, Huairou,
Gucheng). Loaded via `np.load` by `notebooks/experiment_beijing.ipynb`. Source: Zhang et
al., Proc. R. Soc. A 473(2205):20170457, 2017; public via the UCI Machine Learning Repository.

## Note
Path A (verifying the paper's numbers) does not require any of these data files; it reads
only the committed `results/` artifacts. The datasets are needed only for Path B
(regenerating the result files from scratch).
